package com.mirkamol.fortheunicornexam.activity.model

data class Food(val name:String, val foodName:String, val discription:String, val image:Int)
